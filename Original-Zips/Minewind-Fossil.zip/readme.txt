textures by fossil
CIT files/code by 21second and seos